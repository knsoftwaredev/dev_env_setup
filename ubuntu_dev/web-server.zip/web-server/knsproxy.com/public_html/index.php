<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>NginX + Apache2 Reverse Proxy</title>
</head>
<body>
	<?php 
		echo phpinfo(); 
	?>
</body>
</html>