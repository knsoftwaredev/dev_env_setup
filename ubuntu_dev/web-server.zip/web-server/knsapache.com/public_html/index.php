<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>KNS Apache2</title>
</head>
<body>
	<?php echo phpinfo(); ?>
</body>
</html>